import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

def convex_hull(points):
    # Start with the leftmost point
    start = points[0]
    for point in points:
        if point[0] < start[0]:
            start = point

    hull = [start]
    while True:
        next_point = points[0]
        for point in points:
            if point is next_point or not is_left_turn(hull[-1], next_point, point):
                next_point = point
        if next_point is hull[0]:
            break
        hull.append(next_point)
    return hull

def is_left_turn(p1, p2, p3):
    return (p2[0] - p1[0]) * (p3[1] - p1[1]) - (p2[1] - p1[1]) * (p3[0] - p1[0]) > 0

# Generate some random 3D points
points = np.random.rand(30, 3)

# Compute the convex hull of the points
hull = convex_hull(points)

# Create a 3D plot of the points and the convex hull
fig = plt.figure()
ax = fig.add_subplot(111, projection="3d")
ax.scatter(points[:,0], points[:,1], points[:,2])
for i in range(len(hull)):
    if i == len(hull) - 1:
        ax.plot([hull[i][0], hull[0][0]], [hull[i][1], hull[0][1]], [hull[i][2], hull[0][2]], 'r-')
    else:
        ax.plot([hull[i][0], hull[i+1][0]], [hull[i][1], hull[i+1][1]], [hull[i][2], hull[i+1][2]], 'r-')

plt.show()
